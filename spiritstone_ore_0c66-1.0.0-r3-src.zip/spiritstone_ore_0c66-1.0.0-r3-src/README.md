# 灵石矿源（spiritstone_ore_0c66）

Minecraft 1.20.1 · Forge 47.4.0 · Java 17

## 这个工程是什么

这是一个完整的 Forge 模组 Gradle 工程，包含全部源码、贴图、模型、语言文件、
配方与世界生成配置，以及编译所需的 Gradle 包装文件。

## 目录说明

- `src/main/java/`：全部 Java 源代码（方块、物品、灵根/灵力/境界属性、HUD 等）
- `src/main/resources/`：贴图、方块/物品模型、语言文件、战利品表、矿物生成配置
- `src/main/resources/META-INF/mods.toml`：模组元数据（版本、依赖等），里面是构建时替换的占位符
- `build.gradle`、`settings.gradle`、`gradle.properties`：构建配置
- `gradlew`、`gradlew.bat`、`gradle/wrapper/`：Gradle 包装文件，不用另外装 Gradle

## 怎么编译

先装好 JDK 17（Java 17），然后：

- Windows：双击或在工程目录运行 `gradlew.bat build`
- macOS / Linux：在工程目录运行 `./gradlew build`

第一次编译需要联网下载 Gradle 与 Forge 依赖，会比较慢，属正常现象。

编译成功后，成品 jar 在 `build/libs/` 里，名字形如
`spiritstone_ore_0c66-1.0.0-r3.jar`，把它丢进游戏的 `mods` 文件夹就能用。

## 版本信息

- Minecraft 1.20.1
- Forge 47.4.0
- Gradle 8.12.1
- Java 17
