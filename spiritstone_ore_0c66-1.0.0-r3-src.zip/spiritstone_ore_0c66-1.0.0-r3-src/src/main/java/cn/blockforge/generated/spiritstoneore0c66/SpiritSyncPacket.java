package cn.blockforge.generated.spiritstoneore0c66;

import java.util.function.Supplier;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

/**
 * 服务端 -> 客户端：把玩家的灵根、灵力、境界同步给本人。
 */
public class SpiritSyncPacket {
    private final String root;
    private final int mana;
    private final String realm;

    public SpiritSyncPacket(String root, int mana, String realm) {
        this.root = root;
        this.mana = mana;
        this.realm = realm;
    }

    public SpiritSyncPacket(FriendlyByteBuf buf) {
        this.root = buf.readUtf(32);
        this.mana = buf.readVarInt();
        this.realm = buf.readUtf(32);
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeUtf(this.root, 32);
        buf.writeVarInt(this.mana);
        buf.writeUtf(this.realm, 32);
    }

    public void handle(Supplier<NetworkEvent.Context> context) {
        NetworkEvent.Context ctx = context.get();
        ctx.enqueueWork(() -> SpiritClientData.update(this.root, this.mana, this.realm));
        ctx.setPacketHandled(true);
    }
}
