package cn.blockforge.generated.spiritstoneore0c66;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * 服务端事件：登录时补默认值并同步、死亡重生时保留属性、以及调试用的 /spirit 指令。
 */
@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID)
public final class SpiritEvents {
    private static final String[] ROOT_IDS = {"metal", "wood", "water", "fire", "earth"};
    private static final String[] REALM_IDS = {"qi_early", "qi_mid", "qi_late"};

    private SpiritEvents() {
    }

    @SubscribeEvent
    public static void onPlayerClone(PlayerEvent.Clone event) {
        // 死亡重生或换维度时，把灵根、灵力、境界原样带到新身体上。
        SpiritStats.copy(event.getOriginal(), event.getEntity());
    }

    @SubscribeEvent
    public static void onPlayerRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            SpiritNetwork.sync(player);
        }
    }

    @SubscribeEvent
    public static void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        SpiritStats.ensureDefaults(player);
        SpiritNetwork.sync(player);

        if (SpiritStats.markIntroShown(player)) {
            player.sendSystemMessage(Component.translatable("message." + GeneratedMod.MOD_ID + ".welcome"));
        }
    }

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();
        dispatcher.register(Commands.literal("spirit")
                .then(Commands.literal("get")
                        .executes(ctx -> showStats(ctx.getSource())))
                .then(Commands.literal("mana")
                        .then(Commands.argument("value", IntegerArgumentType.integer(0, SpiritStats.MAX_MANA))
                                .executes(ctx -> setMana(ctx.getSource(),
                                        IntegerArgumentType.getInteger(ctx, "value")))))
                .then(Commands.literal("root")
                        .then(Commands.argument("root", StringArgumentType.word())
                                .suggests((ctx, builder) -> SharedSuggestionProvider.suggest(ROOT_IDS, builder))
                                .executes(ctx -> setRoot(ctx.getSource(),
                                        StringArgumentType.getString(ctx, "root")))))
                .then(Commands.literal("realm")
                        .then(Commands.argument("realm", StringArgumentType.word())
                                .suggests((ctx, builder) -> SharedSuggestionProvider.suggest(REALM_IDS, builder))
                                .executes(ctx -> setRealm(ctx.getSource(),
                                        StringArgumentType.getString(ctx, "realm"))))));
    }

    private static int showStats(CommandSourceStack source) {
        ServerPlayer player = getPlayer(source);
        if (player == null) {
            return 0;
        }
        SpiritStats.ensureDefaults(player);
        source.sendSuccess(() -> Component.translatable("message." + GeneratedMod.MOD_ID + ".stats",
                Component.translatable(SpiritStats.getRoot(player).translationKey()),
                Component.translatable(SpiritStats.getRealm(player).translationKey()),
                SpiritStats.getMana(player),
                SpiritStats.MAX_MANA), false);
        return 1;
    }

    private static int setMana(CommandSourceStack source, int value) {
        ServerPlayer player = getPlayer(source);
        if (player == null) {
            return 0;
        }
        SpiritStats.ensureDefaults(player);
        SpiritStats.setMana(player, value);
        SpiritNetwork.sync(player);
        int mana = SpiritStats.getMana(player);
        source.sendSuccess(() -> Component.translatable("message." + GeneratedMod.MOD_ID + ".mana_set",
                mana, SpiritStats.MAX_MANA), false);
        return mana;
    }

    private static int setRoot(CommandSourceStack source, String rootId) {
        ServerPlayer player = getPlayer(source);
        if (player == null) {
            return 0;
        }
        SpiritStats.Root root = SpiritStats.Root.byId(rootId);
        if (!root.id().equals(rootId)) {
            source.sendFailure(Component.translatable("message." + GeneratedMod.MOD_ID + ".unknown_root", rootId));
            return 0;
        }
        SpiritStats.ensureDefaults(player);
        SpiritStats.setRoot(player, root);
        SpiritNetwork.sync(player);
        source.sendSuccess(() -> Component.translatable("message." + GeneratedMod.MOD_ID + ".root_set",
                Component.translatable(root.translationKey())), false);
        return 1;
    }

    private static int setRealm(CommandSourceStack source, String realmId) {
        ServerPlayer player = getPlayer(source);
        if (player == null) {
            return 0;
        }
        SpiritStats.Realm realm = SpiritStats.Realm.byId(realmId);
        if (!realm.id().equals(realmId)) {
            source.sendFailure(Component.translatable("message." + GeneratedMod.MOD_ID + ".unknown_realm", realmId));
            return 0;
        }
        SpiritStats.ensureDefaults(player);
        SpiritStats.setRealm(player, realm);
        SpiritNetwork.sync(player);
        source.sendSuccess(() -> Component.translatable("message." + GeneratedMod.MOD_ID + ".realm_set",
                Component.translatable(realm.translationKey())), false);
        return 1;
    }

    private static ServerPlayer getPlayer(CommandSourceStack source) {
        try {
            return source.getPlayerOrException();
        } catch (Exception ignored) {
            source.sendFailure(Component.translatable("message." + GeneratedMod.MOD_ID + ".player_only"));
            return null;
        }
    }
}
