package cn.blockforge.generated.spiritstoneore0c66;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

/**
 * 本模组的网络通道：只用来把服务端的属性同步给玩家本人的客户端。
 */
public final class SpiritNetwork {
    private static final String PROTOCOL = "1";

    private static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "main"),
            () -> PROTOCOL,
            PROTOCOL::equals,
            PROTOCOL::equals);

    private SpiritNetwork() {
    }

    @SubscribeEvent
    public static void onCommonSetup(FMLCommonSetupEvent event) {
        CHANNEL.messageBuilder(SpiritSyncPacket.class, 0)
                .encoder(SpiritSyncPacket::encode)
                .decoder(SpiritSyncPacket::new)
                .consumerMainThread(SpiritSyncPacket::handle)
                .add();
    }

    /** 把某个玩家的属性同步给他自己的客户端。 */
    public static void sync(Player player) {
        if (player instanceof ServerPlayer serverPlayer) {
            CHANNEL.send(PacketDistributor.PLAYER.with(() -> serverPlayer),
                    new SpiritSyncPacket(
                            SpiritStats.getRoot(player).id(),
                            SpiritStats.getMana(player),
                            SpiritStats.getRealm(player).id()));
        }
    }
}
