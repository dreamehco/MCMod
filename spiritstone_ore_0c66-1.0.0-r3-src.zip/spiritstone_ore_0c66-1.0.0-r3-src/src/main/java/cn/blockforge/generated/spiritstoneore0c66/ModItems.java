package cn.blockforge.generated.spiritstoneore0c66;

import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, GeneratedMod.MOD_ID);

    public static final RegistryObject<Item> SPIRIT_STONE =
            ITEMS.register("spirit_stone", () -> new Item(new Item.Properties()));

    public static final RegistryObject<Item> SPIRIT_STONE_ORE =
            ITEMS.register("spirit_stone_ore",
                    () -> new BlockItem(ModBlocks.SPIRIT_STONE_ORE.get(), new Item.Properties()));

    private ModItems() {
    }
}
