package cn.blockforge.generated.spiritstoneore0c66.client;

import cn.blockforge.generated.spiritstoneore0c66.GeneratedMod;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * 客户端每帧检查快捷键，决定修士面板开还是关。
 */
@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID, value = Dist.CLIENT)
public final class ClientSpiritEvents {
    private static boolean panelOpen;

    private ClientSpiritEvents() {
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null) {
            panelOpen = false;
            return;
        }
        while (ClientSpiritSetup.PANEL_KEY.consumeClick()) {
            panelOpen = !panelOpen;
        }
    }

    public static boolean isPanelOpen() {
        return panelOpen;
    }
}
