package cn.blockforge.generated.spiritstoneore0c66.client;

import com.mojang.blaze3d.vertex.PoseStack;

import cn.blockforge.generated.spiritstoneore0c66.GeneratedMod;
import cn.blockforge.generated.spiritstoneore0c66.SpiritClientData;
import cn.blockforge.generated.spiritstoneore0c66.SpiritStats;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraftforge.client.gui.overlay.ForgeGui;

/**
 * HUD：物品栏左侧的蓝色灵力球，以及按 K 打开的修士面板（灵根 / 境界）。
 */
public final class SpiritHud {
    private static final int ORB_SIZE = 20;

    /** 每行像素宽度，拼出一个 20x20 的圆。 */
    private static final int[] ORB_ROW_WIDTH = {
            6, 10, 13, 15, 16, 17, 18, 19, 19, 20,
            20, 19, 19, 18, 17, 16, 15, 13, 10, 6
    };

    /** 每行颜色，从上到下由亮蓝平滑过渡到深蓝。 */
    private static final int[] ORB_ROW_COLOR = {
            0xFF9FD4FF, 0xFF96CEFC, 0xFF8AC6F8, 0xFF7EBCF4,
            0xFF71B2F0, 0xFF66A8EC, 0xFF5C9EE7, 0xFF5395E2,
            0xFF4B8CDD, 0xFF4483D6, 0xFF3E7BCE, 0xFF3A73C6,
            0xFF366CBE, 0xFF3265B6, 0xFF2E5EAD, 0xFF2B57A4,
            0xFF28509B, 0xFF254A92, 0xFF224489, 0xFF1F3F80
    };

    private SpiritHud() {
    }

    public static void render(ForgeGui gui, GuiGraphics graphics, float partialTick, int width, int height) {
        Minecraft minecraft = gui.getMinecraft();
        if (minecraft.player == null || minecraft.options.hideGui) {
            return;
        }

        renderManaOrb(graphics, minecraft, width, height);

        if (ClientSpiritEvents.isPanelOpen()) {
            renderPanel(graphics, minecraft);
        }
    }

    /** 物品栏左侧的蓝色灵力球，球上写着当前灵力数字。 */
    private static void renderManaOrb(GuiGraphics graphics, Minecraft minecraft, int width, int height) {
        int hotbarLeft = width / 2 - 91;
        int orbX = hotbarLeft - ORB_SIZE - 6;
        int orbY = height - ORB_SIZE - 2;

        for (int row = 0; row < ORB_ROW_WIDTH.length; row++) {
            int rowWidth = ORB_ROW_WIDTH[row];
            int inset = (ORB_SIZE - rowWidth) / 2;
            graphics.fill(orbX + inset, orbY + row, orbX + inset + rowWidth, orbY + row + 1, ORB_ROW_COLOR[row]);
        }

        // 左上角高光，让球看起来是立体的。
        graphics.fill(orbX + 5, orbY + 3, orbX + 9, orbY + 5, 0xFFE9F4FF);
        graphics.fill(orbX + 4, orbY + 5, orbX + 6, orbY + 7, 0xFFCDE5FF);

        String text = String.valueOf(SpiritClientData.mana());
        PoseStack pose = graphics.pose();
        pose.pushPose();
        pose.translate(orbX + ORB_SIZE / 2.0D, orbY + 7.0D, 0.0D);
        pose.scale(0.7F, 0.7F, 1.0F);
        graphics.drawCenteredString(minecraft.font, text, 0, 0, 0xFFFFFFFF);
        pose.popPose();
    }

    /** 按 K 才出现的修士面板：灵根、境界、灵力。 */
    private static void renderPanel(GuiGraphics graphics, Minecraft minecraft) {
        Font font = minecraft.font;

        int panelX = 6;
        int panelY = 6;
        int panelWidth = 132;
        int panelHeight = 64;

        graphics.fill(panelX, panelY, panelX + panelWidth, panelY + panelHeight, 0xC8060E1C);
        graphics.fill(panelX, panelY, panelX + panelWidth, panelY + 1, 0xFF4A90E2);
        graphics.fill(panelX, panelY + panelHeight - 1, panelX + panelWidth, panelY + panelHeight, 0xFF4A90E2);
        graphics.fill(panelX, panelY, panelX + 1, panelY + panelHeight, 0xFF4A90E2);
        graphics.fill(panelX + panelWidth - 1, panelY, panelX + panelWidth, panelY + panelHeight, 0xFF4A90E2);

        Component rootName = Component.translatable(SpiritClientData.root().translationKey());
        Component realmName = Component.translatable(SpiritClientData.realm().translationKey());

        int textX = panelX + 8;
        int textY = panelY + 6;
        graphics.drawString(font, Component.translatable("gui." + GeneratedMod.MOD_ID + ".panel_title"),
                textX, textY, 0xFF8FD3FF);
        textY += 13;
        graphics.drawString(font, Component.translatable("gui." + GeneratedMod.MOD_ID + ".root_line", rootName),
                textX, textY, 0xFFE8E8E8);
        textY += 12;
        graphics.drawString(font, Component.translatable("gui." + GeneratedMod.MOD_ID + ".realm_line", realmName),
                textX, textY, 0xFFE8E8E8);
        textY += 12;
        graphics.drawString(font, Component.translatable("gui." + GeneratedMod.MOD_ID + ".mana_line",
                        SpiritClientData.mana(), SpiritStats.MAX_MANA),
                textX, textY, 0xFFB8D8FF);
    }
}
