package cn.blockforge.generated.spiritstoneore0c66;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;

/**
 * 修仙基础属性：灵根、灵力值、境界。
 *
 * <p>数据保存在玩家自己的持久化 NBT（{@link Player#getPersistentData()}）里，
 * 服务端是唯一权威，客户端只拿到同步过来的副本用于显示。</p>
 */
public final class SpiritStats {
    /** 灵力值上限。 */
    public static final int MAX_MANA = 100;

    private static final String KEY_ROOT = "SpiritRoot";
    private static final String KEY_MANA = "SpiritMana";
    private static final String KEY_REALM = "SpiritRealm";
    private static final String KEY_INTRO = "SpiritIntroShown";

    /** 五行灵根。 */
    public enum Root {
        METAL("metal"),
        WOOD("wood"),
        WATER("water"),
        FIRE("fire"),
        EARTH("earth");

        private final String id;

        Root(String id) {
            this.id = id;
        }

        public String id() {
            return this.id;
        }

        public String translationKey() {
            return "spirit_root." + GeneratedMod.MOD_ID + "." + this.id;
        }

        public static Root byId(String id) {
            for (Root root : values()) {
                if (root.id.equals(id)) {
                    return root;
                }
            }
            return FIRE;
        }
    }

    /** 练气期境界。 */
    public enum Realm {
        QI_EARLY("qi_early"),
        QI_MID("qi_mid"),
        QI_LATE("qi_late");

        private final String id;

        Realm(String id) {
            this.id = id;
        }

        public String id() {
            return this.id;
        }

        public String translationKey() {
            return "spirit_realm." + GeneratedMod.MOD_ID + "." + this.id;
        }

        public static Realm byId(String id) {
            for (Realm realm : values()) {
                if (realm.id.equals(id)) {
                    return realm;
                }
            }
            return QI_EARLY;
        }
    }

    private SpiritStats() {
    }

    /** 玩家第一次被这个模组碰到时，把默认属性写进去：火灵根、灵力 100、练气初期。 */
    public static void ensureDefaults(Player player) {
        CompoundTag tag = player.getPersistentData();
        if (!tag.contains(KEY_ROOT)) {
            tag.putString(KEY_ROOT, Root.FIRE.id());
        }
        if (!tag.contains(KEY_MANA)) {
            tag.putInt(KEY_MANA, MAX_MANA);
        }
        if (!tag.contains(KEY_REALM)) {
            tag.putString(KEY_REALM, Realm.QI_EARLY.id());
        }
    }

    public static Root getRoot(Player player) {
        CompoundTag tag = player.getPersistentData();
        return Root.byId(tag.contains(KEY_ROOT) ? tag.getString(KEY_ROOT) : Root.FIRE.id());
    }

    public static void setRoot(Player player, Root root) {
        player.getPersistentData().putString(KEY_ROOT, root.id());
    }

    public static int getMana(Player player) {
        CompoundTag tag = player.getPersistentData();
        if (!tag.contains(KEY_MANA)) {
            return MAX_MANA;
        }
        return clampMana(tag.getInt(KEY_MANA));
    }

    public static void setMana(Player player, int mana) {
        player.getPersistentData().putInt(KEY_MANA, clampMana(mana));
    }

    public static Realm getRealm(Player player) {
        CompoundTag tag = player.getPersistentData();
        return Realm.byId(tag.contains(KEY_REALM) ? tag.getString(KEY_REALM) : Realm.QI_EARLY.id());
    }

    public static void setRealm(Player player, Realm realm) {
        player.getPersistentData().putString(KEY_REALM, realm.id());
    }

    /** 是否已经给玩家发过「按 K 查看属性」的提示。 */
    public static boolean markIntroShown(Player player) {
        CompoundTag tag = player.getPersistentData();
        if (tag.getBoolean(KEY_INTRO)) {
            return false;
        }
        tag.putBoolean(KEY_INTRO, true);
        return true;
    }

    /** 把一个玩家的属性整包复制给另一个玩家（死亡重生、跨维度、换存档角色时用）。 */
    public static void copy(Player from, Player to) {
        CompoundTag source = from.getPersistentData();
        CompoundTag target = to.getPersistentData();
        copyKey(source, target, KEY_ROOT);
        copyKey(source, target, KEY_MANA);
        copyKey(source, target, KEY_REALM);
        copyKey(source, target, KEY_INTRO);
    }

    private static void copyKey(CompoundTag source, CompoundTag target, String key) {
        if (source.contains(key)) {
            target.put(key, source.get(key).copy());
        }
    }

    private static int clampMana(int mana) {
        if (mana < 0) {
            return 0;
        }
        return Math.min(mana, MAX_MANA);
    }
}
