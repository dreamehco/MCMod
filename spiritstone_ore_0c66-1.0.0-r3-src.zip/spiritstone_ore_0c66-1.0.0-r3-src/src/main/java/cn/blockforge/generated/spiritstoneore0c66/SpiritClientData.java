package cn.blockforge.generated.spiritstoneore0c66;

/**
 * 客户端缓存的属性副本，只用来画 HUD，不参与游戏逻辑判定。
 */
public final class SpiritClientData {
    private static volatile SpiritStats.Root root = SpiritStats.Root.FIRE;
    private static volatile int mana = SpiritStats.MAX_MANA;
    private static volatile SpiritStats.Realm realm = SpiritStats.Realm.QI_EARLY;

    private SpiritClientData() {
    }

    public static void update(String rootId, int manaValue, String realmId) {
        root = SpiritStats.Root.byId(rootId);
        mana = Math.max(0, Math.min(manaValue, SpiritStats.MAX_MANA));
        realm = SpiritStats.Realm.byId(realmId);
    }

    public static void reset() {
        root = SpiritStats.Root.FIRE;
        mana = SpiritStats.MAX_MANA;
        realm = SpiritStats.Realm.QI_EARLY;
    }

    public static SpiritStats.Root root() {
        return root;
    }

    public static int mana() {
        return mana;
    }

    public static SpiritStats.Realm realm() {
        return realm;
    }
}
